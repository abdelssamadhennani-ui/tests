ansible-role-springboot_foundation
=========

An Ansible role that deploys LVM and SystemD foundation for Springboot applications to be deployed using the ansible-role-springboot role.

> **Disclaimer:**
> - The stable versions of the role are tagged. You can find all the available tags with their release notes under Repository/Tags. When you import the role in the requirements.yml file we recommend to use a tagged version of the role.
> - You may find the release notes & the a migration guide for the latest versions in the [release-notes.md](release-notes.md) file.

Requirements:
-------------
- The Springboot application services will being handled as instances of a SystemD template service (not if `sb_become` is set on no/false).

- This Role requires "root" access to install and manage services, also for setting different rights for files & folders with `sb_*_user` and `sb_*_group` ! To avoid that (in case the remote user doesn't have access as root on the server), one (the user, role consumer) should set `sb_become`=no(or false), and to be sure that `sb_*_user` variables are set the remote user !


Role Variables:
---------------
- Default variables (from defaults/main.yml):
    - `sb_root`     : The root directory for all Springboot material (defaults to /opt/springboot)
    - `sb_logroot`  : The root directory for all Springboot logs (defaults to /var/log/springboot)
    - `sb_srvroot`  : The root directory for all Springboot tmp/cache/work files (defaults to /srv/springboot)
    - `sb_user`     : The generic user for the Springboot application used as ownership user. Default value: "springboot"
    - `sb_group`    : The generic group for the Springboot application used as ownership group. Default value: "springboot"

    - `sb_become`   : Should the role try to switch the unix-user to root to be able to create LVM structures, to install & manage the Springboot application service, and set some ownerships for some directories & files ?

- Playbook variables which **MAY** be changed at playbook level:
    - `sb_dedicated_lv` : yes/no whether the foundation role should create dedicated LVs/FSes for Springboot (defaults to "yes")
    - `sb_dedicated_pv` : the disk (or partition) device on which the foundation roles will build the Springboot dedicated volume group (defaults to "/dev/sdb")

Role execution flow:
--------------------
At runtime, the role will perform the following actions:
- Create the Springboot LVM objects (if applicable):
  - Build the springbootVG volume group on the dedicated disk device
  - Build the logical volume and XFS filesystem for the Springboot root installation
  - Build the logical volume and XFS filesystem for the Springboot logs root directory
  - Build the logical volume and XFS filesystem for the Springboot tmp/cache/work root directory
- Create the Springboot root installation and logs root directories
- Create the Springboot SystemD template/instanciated service unit

Dependencies:
-------------
- RHEL 7 or 8 (might work with any Linux distro, if `sb_become` is set on `no`/`false` => no Linux service will be used)
- `ansible` version >= 2.5.0
- linux (RHEL) packages: `bash`, `procps`, `selinux-policy-devel`
- linux (RHEL) packages: `systemd` for *RHEL7* and *RHEL8*, if `sb_become`


Usage:
-----
Via `requirements.yml`:

```yaml
---

- name: ansible-role-springboot_foundation
  src: https://gitlab.ing.net/CDAns/ansible-role-springboot_foundation.git
  scm: git
  version: a tag of the role

```
