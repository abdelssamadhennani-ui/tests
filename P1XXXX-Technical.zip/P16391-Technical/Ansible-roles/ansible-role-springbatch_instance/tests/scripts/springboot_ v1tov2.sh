#!/bin/bash
#
# By Bogdan-Nicolae.Velcea@ing.com
#

trap '[ -n "$outfile" -a -f "$outfile" ] && rm -f "$outfile"; exit 0' EXIT

set -e

if [ "$#" -lt 1 ]; then
  echo "syntax: $0 sprinbboot_conf_file.yml" >&2
  exit 1
fi
infile="$1"
if [ ! -f "$infile" ]; then
  echo "There is no such file \"$infile\" !" >&2
  exit 1
fi
outfile=$(mktemp -u /tmp/$(basename "$0").XXXXXX)
cp -f "$infile" "$outfile"
sed -ri 's/(^|[^a-zA-Z0-9_])springboot_(version|appname|appjarname|workdir|appbase|jar_location|appbase_conf_location|user|group|service_name|run_handlers|run_handlers)([^a-zA-Z0-9_])/\1sb_\2\3/g;s/(^|[^a-zA-Z0-9_])springboot_playbook_template_conf_location([^a-zA-Z0-9_])/\1sb_conf_src\2/g;s/(^|[^a-zA-Z0-9_])springboot_playbook_template_keystore_location([^a-zA-Z0-9_])/\1sb_keystores_src\2/g;s/(^|[^a-zA-Z0-9_])springboot_appbase_keystore_location([^a-zA-Z0-9_])/\1sb_keystores_dest\2/g' "$outfile"
if diff -q "$infile" "$outfile" >/dev/null; then
  echo "Nothing changed !"
  rm -f "$outfile"
else
  echo "File changed !"
  mv -f "$outfile" "$infile"
fi
