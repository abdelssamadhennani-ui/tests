ansible-role-selinux-sprinboot-sabat
=========

This role provides access to a Springboot application to the  

Requirements
------------

To be able to work correctly, this role requires the springboot SELinux module to be installed first.

Role Variables
--------------

This role can take **sabat_port** as a variable. By default it is set to 9446.

Dependencies
------------

No dependencies at this time.

License
-------

BSD

Author Information
------------------

Written by Laurent GAILLARD <laurent.gaillard@ing.com>
